import mongoose from 'mongoose';

let isConnected = false;

async function connect(url) {
    if (!url) {
        throw new Error("MongoDB connection string URL is required");
    }

    if (isConnected) {
        console.log("✅ Using existing database connection");
        return;
    }

    try {
        console.log("🔄 Connecting to database...");
        
        mongoose.set('strictQuery', true);
        
        const options = {
            useNewUrlParser: true,
            useUnifiedTopology: true
        };

        const conn = await mongoose.connect(url, options);
        
        isConnected = true;
        console.log(`✅ Database connected: ${conn.connection.host}`);
        console.log(`📊 Database name: ${conn.connection.name}`);

        // Connection event handlers
        mongoose.connection.on('connected', () => {
            console.log('🔗 Mongoose connected to MongoDB');
            isConnected = true;
        });

        mongoose.connection.on('error', (err) => {
            console.error('❌ Database connection error:', err.message);
            isConnected = false;
        });

        mongoose.connection.on('disconnected', () => {
            console.log('📤 Mongoose disconnected from MongoDB');
            isConnected = false;
        });

        // Handle app termination
        process.on('SIGINT', async () => {
            try {
                await mongoose.connection.close();
                console.log('🔒 Database connection closed through app termination');
                process.exit(0);
            } catch (err) {
                console.error('❌ Error closing database connection:', err);
                process.exit(1);
            }
        });

    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        isConnected = false;
        
        // More specific error messages
        if (error.message.includes('authentication failed')) {
            console.error('🔐 Check your MongoDB username and password');
        } else if (error.message.includes('network')) {
            console.error('🌐 Check your network connection and MongoDB URI');
        } else if (error.message.includes('timeout')) {
            console.error('⏱️ Connection timeout - check if MongoDB Atlas IP whitelist includes your server');
        }
        
        throw error;
    }
}

export default connect;
export { isConnected };